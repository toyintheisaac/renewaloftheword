<?php
require 'req/coonnect.php';

session_unset();
session_destroy();
 
		header('Location: index.php');
 

?>