<?php include "req/coonnect.php";?>



<?php
 $currentProductFolder 	= basename(__DIR__);
 $currentProductFolder2 = basename(getcwd()); 
 $currentProductFilename =  basename(__FILE__,'.php'); 
?>

<?php include "Tempss/post.php";?>