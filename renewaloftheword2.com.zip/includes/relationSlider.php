
<div id="demo" class="carousel slide mb-2" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/image1.jpg" alt="Los Angeles" style='width:100%;height:100%;max-height:300px;'>
      <div class="carousel-caption">
        <h3 class="d-none d-sm-block">Christian Relationship</h3>
      </div>   
    </div> 
  </div> 
</div>