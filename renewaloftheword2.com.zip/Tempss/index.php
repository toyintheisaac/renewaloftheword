
<?php  
	header('Location: https://www.renewaloftheword.com');
?>